---
name: Modern Technical Architecture
colors:
  surface: '#f7f9fb'
  surface-dim: '#d8dadc'
  surface-bright: '#f7f9fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f2f4f6'
  surface-container: '#eceef0'
  surface-container-high: '#e6e8ea'
  surface-container-highest: '#e0e3e5'
  on-surface: '#191c1e'
  on-surface-variant: '#434655'
  inverse-surface: '#2d3133'
  inverse-on-surface: '#eff1f3'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#712ae2'
  on-secondary: '#ffffff'
  secondary-container: '#8a4cfc'
  on-secondary-container: '#fffbff'
  tertiary: '#4d556b'
  on-tertiary: '#ffffff'
  tertiary-container: '#656d84'
  on-tertiary-container: '#eef0ff'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#eaddff'
  secondary-fixed-dim: '#d2bbff'
  on-secondary-fixed: '#25005a'
  on-secondary-fixed-variant: '#5a00c6'
  tertiary-fixed: '#dae2fd'
  tertiary-fixed-dim: '#bec6e0'
  on-tertiary-fixed: '#131b2e'
  on-tertiary-fixed-variant: '#3f465c'
  background: '#f7f9fb'
  on-background: '#191c1e'
  surface-variant: '#e0e3e5'
typography:
  headline-xl:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '700'
    lineHeight: 32px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  headline-sm:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 16px
  margin-mobile: 20px
  margin-desktop: 40px
  sidebar-width: 280px
---

## Brand & Style

This design system is built on a foundation of **Corporate Modernism** blended with **Academic Precision**. It is designed for a technical audience that values clarity, efficiency, and professional reliability. The aesthetic is clean and high-contrast, utilizing generous whitespace to reduce cognitive load in complex project management environments.

The visual language evokes a sense of "Engineered Quality"—it is structured, logical, and intentional. While the primary vibe is professional, the use of vibrant indigo and violet accents ensures the interface feels contemporary and energetic, moving away from "stale" enterprise software toward a more dynamic SaaS experience.

## Colors

The palette is anchored by **Primary Blue (#2563EB)**, signifying trust and technical authority. **Secondary Purple (#7C3AED)** is utilized for high-action areas and creative transitions, providing a sophisticated "SaaS" lift to the interface.

- **Backgrounds:** Use the neutral Slate-50 (#F8FAFC) for page backgrounds to keep the UI light. Use pure white (#FFFFFF) for cards and elevated containers to create a clear "layering" effect.
- **Typography:** The primary text color is Slate-900 (#0F172A). For secondary meta-data or hints, use a Slate-500 scale to maintain legibility while establishing hierarchy.
- **Semantic Colors:** Success, Warning, and Error colors are saturated to ensure visibility against the light background, following standard accessibility patterns.

## Typography

**Inter** is the sole typeface for this design system. Its geometric yet humanist qualities provide the "academic-professional" look required for technical SaaS products. 

- **Headlines:** Use tighter letter-spacing (-0.01em to -0.02em) for larger sizes to maintain a compact, "designed" feel.
- **Body:** Stick to standard tracking for maximum readability in documentation and project descriptions.
- **Hierarchy:** Use font weight (SemiBold 600 vs Regular 400) rather than just size to distinguish between interactive labels and static content.
- **Readability:** Maintain a line height of at least 1.5x for body text to ensure long-form project requirements are easy to scan.

## Layout & Spacing

This design system employs an **8px linear scale** for all spacing and layout decisions. This ensures mathematical harmony across the UI.

- **Mobile (Client/Developer Apps):** Utilize a fluid 4-column grid with 20px outside margins. Navigation is primarily handled through a sticky bottom-bar for thumb-reachability.
- **Desktop (Admin Web):** A 12-column grid with a fixed **280px left-hand sidebar**. The sidebar should be high-contrast (Dark Slate background) to distinguish navigation from the workspace content.
- **Reflow:** As the screen scales to tablet, the sidebar may collapse into a rail or hamburger menu, and grid columns should consolidate to 8.
- **Consistency:** All vertical rhythm should be increments of 8px (e.g., 16px between related items, 32px between sections).

## Elevation & Depth

To maintain a clean SaaS aesthetic, elevation is achieved through **Ambient Shadows** and **Tonal Layering** rather than heavy borders.

- **Surface Levels:** 
    - **Level 0 (Background):** Slate-50 (#F8FAFC). No shadow.
    - **Level 1 (Cards/Content):** White (#FFFFFF). A soft, low-opacity shadow (4px blur, 2% opacity black) and a 1px Slate-200 border.
    - **Level 2 (Modals/Dropdowns):** White (#FFFFFF). A more pronounced shadow (12px blur, 8% opacity black) to signify a higher Z-index.
- **Glassmorphism (Subtle):** Use a light backdrop blur (8px-12px) for sticky headers to maintain a sense of context as users scroll through long lists.

## Shapes

The shape language is defined by a **Medium Roundedness** profile. This softens the "technical" edge of the product, making it more approachable for clients while remaining professional for developers.

- **Standard Elements:** Buttons and Input fields use `rounded-md` (0.5rem / 8px).
- **Containers:** Large cards and project modules use `rounded-lg` (1rem / 16px).
- **Specialty Elements:** User avatars should always be circular. Status chips (Success/Error tags) use a pill shape (Full Rounded) to differentiate them from interactive buttons.

## Components

### Buttons
- **Primary:** Solid #2563EB with White text. Use a subtle gradient to #7C3AED on hover for a modern "SaaS" feel.
- **Secondary:** White background with #2563EB border and text.
- **Ghost:** No background/border; Blue text. Used for less prominent actions.

### Cards
- Use white backgrounds with 16px rounded corners.
- Padding should be 24px (`lg`) to provide "comfortable spacing" requested in the brief.

### Input Fields
- Heights should be 40px (Mobile) and 44px (Desktop).
- Use Slate-100 for the background in an "unfocused" state, shifting to White with a 2px Blue border when "focused."

### Lists & Navigation
- **Sidebar (Admin):** Use active-state indicators (a 4px vertical blue line on the left edge) to show current location.
- **Mobile Bottom Nav:** Use minimalist line-art icons (24px) with 12px labels in Bold weight.

### Chips & Badges
- Use a light tint of the semantic color for the background (e.g., 10% opacity Green) with the full-strength color for the text (Success Green).